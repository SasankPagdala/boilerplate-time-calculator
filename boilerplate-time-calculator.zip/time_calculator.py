week_days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday',
  'Saturday']

def add_time(start, duration, *args):
    [S, meridiem] = start.split(" ")
    [StartH, StartM] = S.split(":")
    [DH, DM] = duration.split(":")

  #Definitions
    output_minutes = int(StartM) + int(DM)
    output_hours = int(StartH) + int(DH)
    future_days = 0

  #Adding parameters to output_minutes and output_hours  
    if output_minutes >= 60:
      #add an hour and subtract by 60
      output_minutes -= 60
      output_hours += 1
    if output_minutes < 10:
      output_minutes = f"{output_minutes}".zfill(2)
      
  #Prints     
    if output_hours >= 12:
      t, r  = divmod(output_hours, 12)
      output_hours = r if r else output_hours
      if output_hours > 12:
        #condition that has specific parameters 
        #for output_hours that work for multiples of 12
        output_hours = output_hours - ((t-1) * 12)

      if t > 0:
        if meridiem == 'PM':
          future_days = ((t-1) // 2) + 1
        else:
          future_days = t // 2
      
      if t > 0 and t % 2 != 0:
        meridiem = 'AM' if meridiem == 'PM' else 'PM' 


        
    #print statement tests
    new_time = str(output_hours) + ":"
    new_time += str(output_minutes) + f" {meridiem}"

    if args:
      day = args[0].title()
      if future_days > 0:
        # taking the index of the day from the parameter
        index = week_days.index(day)
        # and then find that index plus the future_days
        index += future_days % 7
        # if index is greater than list length restart from beginning
        if index > 6:
          index = index - 7
        #reset the day
        day = week_days[index]
      new_time += f", {day}"

  #Formatting 
    if future_days == 1:
      new_time += "(next day)".rjust(11)
    elif future_days > 1:
      new_time += f" ({future_days} days later)".rjust(11)
    return new_time




# print(add_time("3:00 PM", "3:10"))
# print(add_time("11:30 AM", "2:32", "Monday"))
# print(add_time("11:43 AM", "00:20"))
# print(add_time("10:10 PM", "3:30"))
# print(add_time("11:43 PM", "24:20", "tueSday"))
# print(add_time("6:30 PM", "205:12"))
# print(add_time("5:01 AM", "0:00"))
# print(add_time("8:16 PM", "466:02", "tuesday"))